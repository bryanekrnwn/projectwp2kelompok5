<?php
class mu_login extends CI_Model{
    function cekadmin($username,$password){
        $hasil=$this->db->query("SELECT * FROM tbl_user WHERE username='$username' AND password=md5('$password')");
        return $hasil;
    }
  
}
